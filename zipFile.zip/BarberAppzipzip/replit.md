# Barber-Flow

Sistema de gestão para barbearias e estabelecimentos multi-serviços.

## Mudanças Recentes
- Remoção do modal de login inicial obrigatório.
- Atualização da interface de login para um design mais limpo e moderno.
- Ajuste na navegação para permitir visualização da Home sem autenticação prévia (funcionalidades protegidas continuam exigindo login).
